#!/usr/bin/env bash
# install.sh — one-time setup for Local Whisper Dictation
set -e

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Local Whisper Dictation — Installer"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# 1. Make sure pip is available
if ! command -v pip3 &>/dev/null; then
  echo "❌ pip3 not found. Make sure Python is installed via brew."
  exit 1
fi

echo "📦 Installing Python dependencies…"
echo ""

pip3 install --upgrade \
  lightning-whisper-mlx \
  sounddevice \
  pynput \
  numpy

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅  All dependencies installed!"
echo ""
echo "▶  To run the dictation app:"
echo ""
echo "     python3 dictate.py"
echo ""
echo "⚠️  macOS permissions needed (first run):"
echo "   • Microphone  — System Settings → Privacy → Microphone"
echo "   • Accessibility — System Settings → Privacy → Accessibility"
echo "     (required so the app can type into other apps)"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
