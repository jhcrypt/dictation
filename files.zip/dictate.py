#!/usr/bin/env python3
"""
Local Whisper Dictation — Apple Silicon
Hold F8 to record, release to transcribe and type.
100% offline. No API keys. No cloud.
"""

import threading
import tempfile
import os
import sys
import time
import wave
import subprocess

# ── deps ──────────────────────────────────────────────────────────────────────
try:
    import sounddevice as sd
    import numpy as np
    from pynput import keyboard
    from pynput.keyboard import Controller, Key
    from lightning_whisper_mlx import LightningWhisperMLX
except ImportError as e:
    print(f"\n❌ Missing dependency: {e}")
    print("Run the install script first:  bash install.sh\n")
    sys.exit(1)

# ── config ────────────────────────────────────────────────────────────────────
HOTKEY        = Key.f8          # change to e.g. Key.f5 or keyboard.KeyCode(char='`')
MODEL         = "distil-medium.en"   # fast + accurate for English
BATCH_SIZE    = 12
QUANT         = None            # None | "4bit" | "8bit"
SAMPLE_RATE   = 16000
CHANNELS      = 1

# ── globals ───────────────────────────────────────────────────────────────────
recording     = False
audio_frames  = []
typer         = Controller()
whisper       = None            # loaded once at startup

# ── audio helpers ─────────────────────────────────────────────────────────────

def audio_callback(indata, frames, time_info, status):
    if recording:
        audio_frames.append(indata.copy())


def save_wav(frames, path):
    audio = np.concatenate(frames, axis=0)
    with wave.open(path, "wb") as wf:
        wf.setnchannels(CHANNELS)
        wf.setsampwidth(2)          # 16-bit
        wf.setframerate(SAMPLE_RATE)
        wf.writeframes((audio * 32767).astype(np.int16).tobytes())


def transcribe_and_type(wav_path):
    print("⚙️  Transcribing…", end=" ", flush=True)
    result = whisper.transcribe(audio_path=wav_path)
    text   = result.get("text", "").strip()
    if text:
        print(f"✅ "{text}"")
        # small delay so the target app is focused after key release
        time.sleep(0.15)
        typer.type(text)
    else:
        print("(nothing detected)")


# ── hotkey handlers ───────────────────────────────────────────────────────────

def on_press(key):
    global recording, audio_frames
    if key == HOTKEY and not recording:
        recording    = True
        audio_frames = []
        print("🎙  Recording… (release F8 to stop)", end="\r", flush=True)


def on_release(key):
    global recording
    if key == HOTKEY and recording:
        recording = False
        frames    = list(audio_frames)
        if not frames:
            return
        # run transcription off the main thread so key listener stays responsive
        threading.Thread(target=_process, args=(frames,), daemon=True).start()


def _process(frames):
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        wav_path = f.name
    try:
        save_wav(frames, wav_path)
        transcribe_and_type(wav_path)
    finally:
        os.unlink(wav_path)


# ── main ──────────────────────────────────────────────────────────────────────

def main():
    global whisper

    print("\n🔊 Local Whisper Dictation")
    print(f"   Model : {MODEL}  |  Quant : {QUANT or 'none'}")
    print("   Loading model (first run downloads ~500 MB — one time only)…")

    whisper = LightningWhisperMLX(model=MODEL, batch_size=BATCH_SIZE, quant=QUANT)
    print("   ✅ Model ready!\n")
    print(f"   Hold  F8  to record, release to transcribe + type.")
    print("   Press Ctrl-C to quit.\n")

    with sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=CHANNELS,
        dtype="float32",
        callback=audio_callback,
    ):
        with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
            try:
                listener.join()
            except KeyboardInterrupt:
                print("\n👋 Bye!")


if __name__ == "__main__":
    main()
